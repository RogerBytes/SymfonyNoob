<?php

return [
    'Names' => [
        'MYR' => [
            'MYR',
            '马来西亚令吉',
        ],
    ],
];
