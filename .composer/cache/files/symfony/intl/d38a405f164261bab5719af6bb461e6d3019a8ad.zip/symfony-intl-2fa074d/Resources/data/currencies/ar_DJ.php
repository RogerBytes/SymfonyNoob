<?php

return [
    'Names' => [
        'DJF' => [
            'Fdj',
            'فرنك جيبوتي',
        ],
    ],
];
