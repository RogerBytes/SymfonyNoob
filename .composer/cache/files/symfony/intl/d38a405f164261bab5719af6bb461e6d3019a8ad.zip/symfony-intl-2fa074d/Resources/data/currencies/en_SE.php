<?php

return [
    'Names' => [
        'SEK' => [
            'kr',
            'Swedish Krona',
        ],
    ],
];
