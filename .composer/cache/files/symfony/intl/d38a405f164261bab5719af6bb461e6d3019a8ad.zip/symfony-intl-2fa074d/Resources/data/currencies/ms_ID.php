<?php

return [
    'Names' => [
        'IDR' => [
            'Rp',
            'Rupiah Indonesia',
        ],
    ],
];
