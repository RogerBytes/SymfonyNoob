<?php

return [
    'Names' => [
        'ZMW' => [
            'K',
            'Zambian Kwacha',
        ],
    ],
];
