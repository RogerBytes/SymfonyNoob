<?php

return [
    'Names' => [
        'GHS' => [
            'GH₵',
            'Sidi na Ghana',
        ],
    ],
];
