<?php

return [
    'Names' => [
        'GEL' => [
            '₾',
            'Georgian Lari',
        ],
    ],
];
