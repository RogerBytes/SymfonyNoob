<?php

return [
    'Names' => [
        'KYD' => [
            '$',
            'Cayman Islands Dollar',
        ],
    ],
];
