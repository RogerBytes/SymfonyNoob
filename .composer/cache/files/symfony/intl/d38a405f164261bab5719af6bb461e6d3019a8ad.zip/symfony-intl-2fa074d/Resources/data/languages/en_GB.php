<?php

return [
    'Names' => [
        'ff' => 'Fulah',
    ],
    'LocalizedNames' => [],
];
