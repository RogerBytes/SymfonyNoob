<?php

return [
    'Names' => [
        'AZN' => [
            '₼',
            'AZN',
        ],
    ],
];
