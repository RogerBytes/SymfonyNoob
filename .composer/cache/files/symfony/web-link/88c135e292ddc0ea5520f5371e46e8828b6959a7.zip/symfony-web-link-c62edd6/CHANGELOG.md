CHANGELOG
=========

7.4
---

 * Add `HttpHeaderParser` to read `Link` headers from HTTP responses
 * Make `HttpHeaderSerializer` non-final

4.4.0
-----

 * implement PSR-13 directly

3.3.0
-----

 * added the component
