Interpret a Simple DocBlock
==================================

This guide demonstrates how to parse a simple DocBlock and extract its summary and description using ReflectionDocBlock.

.. literalinclude:: ../examples/01-interpreting-a-simple-docblock.php
   :language: php
   :linenos:

