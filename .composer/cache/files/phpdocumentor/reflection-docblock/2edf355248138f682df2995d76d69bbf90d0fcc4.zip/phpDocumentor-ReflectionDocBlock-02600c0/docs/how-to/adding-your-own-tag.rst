Add Your Own Tag
=======================

This guide demonstrates how to add your own custom tag to a DocBlock using ReflectionDocBlock.

.. literalinclude:: ../examples/04-adding-your-own-tag.php
   :language: php
   :linenos:

