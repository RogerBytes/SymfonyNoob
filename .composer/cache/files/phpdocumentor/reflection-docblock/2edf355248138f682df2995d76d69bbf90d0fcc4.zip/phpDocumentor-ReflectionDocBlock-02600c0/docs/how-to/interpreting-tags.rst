Interpret Tags in a DocBlock
===================================

This guide demonstrates how to interpret tags within a DocBlock using ReflectionDocBlock.

.. literalinclude:: ../examples/02-interpreting-tags.php
   :language: php
   :linenos:

