Installation
============

To install ReflectionDocBlock, use Composer:

.. code-block:: bash

   composer require phpdocumentor/reflection-docblock

