<?php

declare(strict_types=1);

namespace phpDocumentor\Reflection\Exception;

use LogicException;

final class CannotCreateTag extends LogicException
{
}
