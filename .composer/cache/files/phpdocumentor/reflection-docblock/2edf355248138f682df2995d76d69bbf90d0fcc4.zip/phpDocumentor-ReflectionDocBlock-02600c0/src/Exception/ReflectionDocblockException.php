<?php

declare(strict_types=1);

namespace phpDocumentor\Reflection\Exception;

use Throwable;

interface ReflectionDocblockException extends Throwable
{
}
